
document.addEventListener('DOMContentLoaded', () => {

    const sliders = document.querySelectorAll('.dog-slider');
  
    sliders.forEach(slider => {
      const slidesContainer = slider.querySelector('.slides-container');
      const prevBtn = slider.querySelector('.prev-btn');
      const nextBtn = slider.querySelector('.next-btn');
      const slides = slidesContainer.children;
      let currentIndex = 0;
  
      
      function showSlide(index) {
        
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;
        currentIndex = index;
      
        const offset = -index * 100; 
        slidesContainer.style.transform = `translateX(${offset}%)`;
      }
  
      prevBtn.addEventListener('click', () => {
        showSlide(currentIndex - 1);
      });
  
      nextBtn.addEventListener('click', () => {
        showSlide(currentIndex + 1);
      });
  
      showSlide(currentIndex);
    });
  });